package di.setter03;

public interface InterMessage {
	public void sayHello();
}
