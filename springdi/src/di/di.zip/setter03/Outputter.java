package di.setter03;

public interface Outputter {
	public void output(String name, String greeting);
}
