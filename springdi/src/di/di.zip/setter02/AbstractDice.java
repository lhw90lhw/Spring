package di.setter02;

public interface AbstractDice{
	public int getDiceValue();
}
