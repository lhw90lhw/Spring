package di.setter02;

public interface AbstractPlayer {
	public void play();
	public int getTotalValue();
}
